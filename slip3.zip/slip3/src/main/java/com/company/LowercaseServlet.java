package com.company;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class LowercaseServlet extends HttpServlet{
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		res.setContentType("text/html");
		
		PrintWriter out = res.getWriter();
		
		String str = req.getParameter("str");
		String lowercase = str.toLowerCase();
		
		out.println("<html><body>");
		out.println("<h3>Original string : " + str + "</h3>");
		out.println("<h3>Lowercase string : " + lowercase + "</h3>");
		out.println("</body></html>");
	}
}
