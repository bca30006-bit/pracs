package com.company;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class PalindromeServlet extends HttpServlet{
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html;charset=UTF-8"); 
		
		String name = request.getParameter("name");
		
		if (name == "") { 
            response.sendRedirect("palindrome.jsp");
            return;
        }
		
		String reversed = new StringBuilder(name).reverse().toString();
		boolean isPalindrome = name.trim().equalsIgnoreCase(reversed.trim());
		
		try (PrintWriter out = response.getWriter()) {
            out.println("<html><body>");
            out.println("<h2>Palindrome Result</h2>");
            out.printf("<p><b>%s</b> is %s a palindrome.</p>", name, isPalindrome ? "" : "NOT");
            out.println("<p><a href=\"/HindujaPractical/palindrome.jsp\">Back</a></p>");
            out.println("</body></html>");
        }
	}
}
