package com.company;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class InsertMovieServlet extends HttpServlet{
	
	String url = "jdbc:mysql://localhost:3306/practical";
	String uname= "root";
	String pass = "root";
	
	@Override
	public void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
		
		resp.setContentType("text/html");		
		PrintWriter out = resp.getWriter();
		
		String id = req.getParameter("id");
        String name = req.getParameter("name");
        String actor = req.getParameter("actor");
        String actress = req.getParameter("actress");
        String director = req.getParameter("director");
        String releaseDate = req.getParameter("releaseDate");
        String ratepoint = req.getParameter("ratepoint");
        
        if (id == null || id.isEmpty() || name == null || name.isEmpty()) {
            out.println("<h3>Error: ID and Name are required.</h3>");
            return;
        }
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection(url, uname, pass);
			
			String query = "insert into movies values (?, ?, ?, ?, ?, ?, ?)";
			
			PreparedStatement pst = con.prepareStatement(query);
			pst.setInt(1, Integer.parseInt(id));
			pst.setString(2, name);
			pst.setString(3, actor);
			pst.setString(4, actress);
			pst.setString(5, director);
			pst.setString(6, releaseDate);
			pst.setFloat(7, Float.parseFloat(ratepoint));
			
			int rows = pst.executeUpdate();
			
			if (rows > 0) {
                out.println("<h3>Movie inserted successfully!</h3>");
            } else {
                out.println("<h3>Insert failed!</h3>");
            }
			
			pst.close();
			con.close();
			
		} catch (Exception e) {
			out.println("<h3>Error insertmovies servlet: " + e + "</h3>");
		}
		
		out.close();
	}
}
